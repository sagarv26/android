package com.example.sagar.callist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Contact extends AppCompatActivity {

    ListView friendslist;
    String[] list={"Sagar","Abhishek","Chethan","Hemanth","Prajwal","Raghunandan","Shreyas","Sourav","Suhas","Vikas","Uttej"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        friendslist=(ListView)findViewById(R.id.friendslist);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(Contact.this,android.R.layout.simple_list_item_1,list);
        friendslist.setAdapter(adapter);

        friendslist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pos= parent.getItemAtPosition(position).toString();

                if(pos.equals("Sagar"))
                {
                    long number=7019161658l;
                    String data=String.valueOf(number);
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    intent.putExtra("number1", data);
                    startActivity(intent);
                }

                if(pos.equals("Abhishek"))
                {
                    long number= 8892702930l;
                    String data=String.valueOf(number);
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    intent.putExtra("number1", data);
                    startActivity(intent);
                }

                if(pos.equals("Chethan"))
                {
                    long number= 9620715377l;
                    String data=String.valueOf(number);
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    intent.putExtra("number1", data);
                    startActivity(intent);
                }


                if(pos.equals("Hemanth"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Prajwal"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Raghunandan"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Sourav"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Shreyas"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Vikas"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Suhas"))
                {
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    startActivity(intent);
                }

                if(pos.equals("Uttej"))
                {
                    long number= 9945723553l;
                    String data=String.valueOf(number);
                    Intent intent=new Intent(Contact.this,MainActivity.class);
                    intent.putExtra("number1", data);
                    startActivity(intent);
                }





            }
        });


    }
}
