package com.example.sagar.callist;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button add,call,sms;
    EditText number;
    String num;

    String[] Storage_Permission={

            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add=(Button)findViewById(R.id.add);
        call=(Button)findViewById(R.id.call);
        sms=(Button)findViewById(R.id.sms);
        number=(EditText)findViewById(R.id.number);

        int sms_permission= ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.SEND_SMS);
        if (sms_permission!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,Storage_Permission,1);
        }

        Bundle b=getIntent().getExtras();
        if(b!=null) {
            final String num = b.getString("number1");
            number.setText(num);
        }
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Contact.class);
                startActivity(i);

            }
        });

        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SmsManager msg =SmsManager.getDefault();
                msg.sendTextMessage(number.getText().toString(),null,"Hi",null,null);
                Toast.makeText(MainActivity.this,"SMS SENT to : "+num,Toast.LENGTH_SHORT).show();

            }
        });

        int call_permission= ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.CALL_PHONE);
        if (call_permission!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,Storage_Permission,1);
        }


        call.setOnClickListener(new View.OnClickListener() {
            @Override
             public void onClick(View v) {

                String myno=number.getText().toString();

                if (myno.trim().isEmpty())
                {
                    Intent intent=new Intent(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:8722548007"));
                    startActivity(intent);

                }
                else
                {
                    Intent intent=new Intent(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:"+myno));
                    startActivity(intent);

                }

//                else if(num.trim().isEmpty())
//                {   Intent intent=new Intent(Intent.ACTION_CALL);
//                    intent.setData(Uri.parse("tel:"+myno));
//                    startActivity(intent);
//                }
//                else {
//                    Intent intent=new Intent(Intent.ACTION_CALL);
//                    intent.setData(Uri.parse("tel:"+num));
//                    startActivity(intent);
//                }

                }
        });


        








    }
}
