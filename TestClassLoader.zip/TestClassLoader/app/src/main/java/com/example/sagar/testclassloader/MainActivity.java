package com.example.sagar.testclassloader;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Properties;

public class MainActivity extends AppCompatActivity {
    private PropertyFile propertyFile;
    private Context context;
    private Properties p;

    TextView ageTV,nameTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        ageTV=(TextView)findViewById(R.id.ageTV);
        nameTV=(TextView)findViewById(R.id.nameTV) ;

        propertyFile = new PropertyFile(context);
        p = propertyFile.getProperties("config.properties");
        String name1=p.getProperty("Name");
        int age1=R.string.age;
        ageTV.setText(age1);
        nameTV.setText(R.string.content);

        Toast.makeText(context,p.getProperty("age"),Toast.LENGTH_SHORT).show();

    }


//        try {
//            String name=PropertyFile.getProperty("name",getApplicationContext());
//            String age=PropertyFile.getProperty("age",getApplicationContext());
//
//            nameTV.setText(name);ageTV.setText(age);
//
//            nameTV.setText(PropertyFile.getProperty("name",getApplicationContext()));
//            ageTV.setText(PropertyFile.getProperty("age",getApplicationContext()));
//
//
//            Toast.makeText(this, "name: "+PropertyFile.getProperty("name",getApplicationContext()), Toast.LENGTH_LONG).show();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//
//    }
}
