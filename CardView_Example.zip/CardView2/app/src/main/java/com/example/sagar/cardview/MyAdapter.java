package com.example.sagar.cardview;

import android.content.Context;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by Sagar on 8/20/2017.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.viewHolder> {

    private List<RecyclerItem> listItem;
    private Context mContext;

    public MyAdapter(List<RecyclerItem> listItem, Context mContext) {
        this.listItem = listItem;
        this.mContext = mContext;
    }

    @Override
    public viewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view,parent,false);
        return new viewHolder(v);
    }

    @Override
    public void onBindViewHolder(final viewHolder holder, final int position) {
        final RecyclerItem item=listItem.get(position);
        holder.title.setText(item.getTitle());
        holder.description.setText(item.getDescription());
        holder.optiondigit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final PopupMenu popupMenu=new PopupMenu(mContext,holder.optiondigit);
                popupMenu.inflate(R.menu.option_menu);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch(item.getItemId()){
                            case R.id.menu_save:
                                Toast.makeText(mContext,"Saved",Toast.LENGTH_SHORT).show();
                                break;
                            case R.id.menu_delete:
                                listItem.remove(position);
                                notifyDataSetChanged();
                                Toast.makeText(mContext,"Deleted",Toast.LENGTH_SHORT).show();
                                break;
                            default:
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItem.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        public TextView title,description,optiondigit;

        public viewHolder(View itemView) {
            super(itemView);
            title=(TextView) itemView.findViewById(R.id.text1);
            description=(TextView) itemView.findViewById(R.id.description);
            optiondigit=(TextView) itemView.findViewById(R.id.optionDigit);

        }
    }
}
