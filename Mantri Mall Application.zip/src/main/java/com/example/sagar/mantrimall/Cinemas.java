package com.example.sagar.mantrimall;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class Cinemas extends AppCompatActivity {

    ImageButton aseat1,aseat2,aseat3,aseat4,aseat5,aseat6,bseat1,bseat2,bseat3,bseat4,bseat5,bseat6,cseat1,cseat2,cseat3,cseat4,cseat5,cseat6,dseat1,dseat2,dseat3,dseat4,dseat5,dseat6,eseat1,eseat2,eseat3,eseat4,eseat5;
    TextView display,tcount;
    int count=0,total_Selected=0;
    Button pay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cinemas);

        display=(TextView)findViewById(R.id.display);
        tcount=(TextView)findViewById(R.id.count);
        pay=(Button)findViewById(R.id.pay);
        aseat1=(ImageButton)findViewById(R.id.aseat1);
        aseat2=(ImageButton)findViewById(R.id.aseat2);
        aseat3=(ImageButton)findViewById(R.id.aseat3);
        aseat4=(ImageButton)findViewById(R.id.aseat4);
        aseat5=(ImageButton)findViewById(R.id.aseat5);
        aseat6=(ImageButton)findViewById(R.id.aseat6);

        bseat1=(ImageButton)findViewById(R.id.bseat1);
        bseat2=(ImageButton)findViewById(R.id.bseat2);
        bseat3=(ImageButton)findViewById(R.id.bseat3);
        bseat4=(ImageButton)findViewById(R.id.bseat4);
        bseat5=(ImageButton)findViewById(R.id.bseat5);
        bseat6=(ImageButton)findViewById(R.id.bseat6);

        cseat1=(ImageButton)findViewById(R.id.cseat1);
        cseat2=(ImageButton)findViewById(R.id.cseat2);
        cseat3=(ImageButton)findViewById(R.id.cseat3);
        cseat4=(ImageButton)findViewById(R.id.cseat4);
        cseat5=(ImageButton)findViewById(R.id.cseat5);
        cseat6=(ImageButton)findViewById(R.id.cseat6);




            aseat1.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        aseat1.setBackgroundColor(Color.GREEN);
                        display.setText("1");

                        count = 1;
                        total_Selected++;
                        tcount.setText(String.valueOf(total_Selected));


                        aseat1.setOnTouchListener(new View.OnTouchListener() {
                            @Override

                            public boolean onTouch(View v, MotionEvent event) {
                                if (event.getAction() == MotionEvent.ACTION_UP) {

                                    aseat1.setBackgroundColor(Color.GREEN);


                                    aseat1.setOnClickListener(new View.OnClickListener() {
                                        @Override

                                        public void onClick(View v) {
                                            count = 2;
                                            if (count == 2) {
                                                aseat1.setBackgroundColor(Color.RED);

                                                LayoutInflater layoutInflater = getLayoutInflater();

                                                View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                                Toast toast = new Toast(getApplicationContext());
                                                toast.setDuration(Toast.LENGTH_SHORT);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.setView(booked1);
                                                toast.show();
                                            }
                                        }

                                    });

                                }
                                return false;
                            }

                        });

                    }
                    return false;
                }
            });


        aseat2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat2.setBackgroundColor(Color.GREEN);
                    display.setText("2");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    aseat2.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat2.setBackgroundColor(Color.GREEN);
                                aseat2.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat2.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        aseat3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat3.setBackgroundColor(Color.GREEN);
                    display.setText("3");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    aseat3.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat3.setBackgroundColor(Color.GREEN);
                                aseat3.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat3.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });


        aseat4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat4.setBackgroundColor(Color.GREEN);
                    display.setText("4");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    aseat4.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat4.setBackgroundColor(Color.GREEN);
                                aseat4.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat4.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        aseat5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat5.setBackgroundColor(Color.GREEN);
                    display.setText("5");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    aseat5.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat5.setBackgroundColor(Color.GREEN);
                                aseat5.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat5.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        aseat6.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat6.setBackgroundColor(Color.GREEN);
                    display.setText("6");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    aseat6.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat6.setBackgroundColor(Color.GREEN);
                                aseat6.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat6.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat1.setBackgroundColor(Color.GREEN);
                    display.setText("1");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    bseat1.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat1.setBackgroundColor(Color.GREEN);
                                bseat1.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat1.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat2.setBackgroundColor(Color.GREEN);
                    display.setText("2");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    bseat2.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat2.setBackgroundColor(Color.GREEN);
                                bseat2.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat2.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat3.setBackgroundColor(Color.GREEN);
                    display.setText("3");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    bseat3.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat3.setBackgroundColor(Color.GREEN);
                                bseat3.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat3.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });


        bseat4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat4.setBackgroundColor(Color.GREEN);
                    display.setText("4");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    bseat4.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat4.setBackgroundColor(Color.GREEN);
                                bseat4.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat4.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat5.setBackgroundColor(Color.GREEN);
                    display.setText("5");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    bseat5.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat5.setBackgroundColor(Color.GREEN);
                                bseat5.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat5.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat6.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat6.setBackgroundColor(Color.GREEN);
                    display.setText("6");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    bseat6.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat6.setBackgroundColor(Color.GREEN);
                                bseat6.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat6.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        cseat1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    cseat1.setBackgroundColor(Color.GREEN);
                    display.setText("1");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    cseat1.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                cseat1.setBackgroundColor(Color.GREEN);
                                cseat1.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            cseat1.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        cseat2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    cseat2.setBackgroundColor(Color.GREEN);
                    display.setText("2");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    cseat2.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                cseat2.setBackgroundColor(Color.GREEN);
                                cseat2.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            cseat2.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        cseat3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    cseat3.setBackgroundColor(Color.GREEN);
                    display.setText("3");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    cseat3.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                cseat3.setBackgroundColor(Color.GREEN);
                                cseat3.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            cseat3.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });


        cseat4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    cseat4.setBackgroundColor(Color.GREEN);
                    display.setText("4");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    cseat4.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                cseat4.setBackgroundColor(Color.GREEN);
                                cseat4.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            cseat4.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        cseat5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    cseat5.setBackgroundColor(Color.GREEN);
                    display.setText("5");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    cseat5.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                cseat5.setBackgroundColor(Color.GREEN);
                                cseat5.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            cseat5.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        cseat6.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    cseat6.setBackgroundColor(Color.GREEN);
                    display.setText("6");
                    count=1;
                    total_Selected++;
                    tcount.setText(String.valueOf(total_Selected));

                    cseat6.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                cseat6.setBackgroundColor(Color.GREEN);
                                cseat6.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            cseat6.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String data=String.valueOf(total_Selected);
                Intent intent=new Intent(Cinemas.this,Pay_Cinemas.class);
                intent.putExtra("total", data);
//                Bundle extras = new Bundle();
//                extras.putInt("total", total_Selected);
//                intent.putExtras(extras);
                startActivity(intent);

            }
        });


    }
}
