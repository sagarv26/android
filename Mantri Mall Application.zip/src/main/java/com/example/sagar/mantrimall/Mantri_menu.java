package com.example.sagar.mantrimall;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

public class Mantri_menu extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    GridView menu_grid;
    String[] string_menu = {"Shopping Page", "Take Selfi", "Mall Map", "Book Bus/Cab", "Call/Meassage Friend"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mantri_menu);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        menu_grid = (GridView) findViewById(R.id.mallmenu_grid);
        menu_grid.setColumnWidth(150);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Mantri_menu.this, android.R.layout.simple_list_item_1, string_menu);
        menu_grid.setAdapter(adapter);

        menu_grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String pos = parent.getItemAtPosition(position).toString();

                Toast.makeText(Mantri_menu.this, "Selected Shop is :" + pos, Toast.LENGTH_SHORT).show();

                if (pos.equals("Shopping Page")) {
                    Intent intent = new Intent(Mantri_menu.this, Shoppingpage.class);
                    startActivity(intent);
                }

                if (pos.equals("Take Selfi")) {
                    Intent intent = new Intent(Mantri_menu.this, Take_selfi.class);
                    startActivity(intent);
                }

            }

        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                Intent intent=new Intent(Mantri_menu.this,MainActivity.class);
                startActivity(intent);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
            switch (item.getItemId()) {
                case R.id.optionlogin:
                    Intent intent2 = new Intent(Mantri_menu.this, MainActivity.class);
                    startActivity(intent2);
                    return true;

                case R.id.optionsetting:
                    Intent intent3 = new Intent(Mantri_menu.this, MainActivity.class);
                    startActivity(intent3);
                    return true;

                case R.id.optioncontact:
                    Intent intent4 = new Intent(Mantri_menu.this, MainActivity.class);
                    startActivity(intent4);

                    return true;

                case R.id.optionhome:
                    Intent intent5 = new Intent(Mantri_menu.this, MainActivity.class);
                    startActivity(intent5);

                    return true;

                default:
                    return super.onOptionsItemSelected(item);
            }
    }

        @SuppressWarnings("StatementWithEmptyBody")
        @Override
        public boolean onNavigationItemSelected (MenuItem item){
            // Handle navigation view item clicks here.
            int id = item.getItemId();

            if (id == R.id.nav_camera) {
                // Handle the camera action
            } else if (id == R.id.nav_gallery) {

            } else if (id == R.id.nav_slideshow) {

            } else if (id == R.id.nav_manage) {

            } else if (id == R.id.nav_share) {

            } else if (id == R.id.nav_send) {

            }

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            drawer.closeDrawer(GravityCompat.START);
            return true;
        }
    }

