package com.example.sagar.mantrimall;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Shoppingpage extends AppCompatActivity {

    ListView listview;
    String[] list= {"PVR Cinemas","Pizza Hut","Reliance","Foodcart","Nike","McDonalds","Cinemas"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoppingpage);

        listview = (ListView)findViewById(R.id.listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Shoppingpage.this,android.R.layout.simple_list_item_1,list);

        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String pos =  parent.getItemAtPosition(position).toString();

                Toast.makeText(Shoppingpage.this,"Selected Shop is :"+pos,Toast.LENGTH_SHORT).show();

                if(pos.equals("PVR Cinemas"))
                {
                    Intent intent=new Intent(Shoppingpage.this,PVR.class);
                    startActivity(intent);
                }

                if(pos.equals("Cinemas"))
                {
                    Intent intent1=new Intent(Shoppingpage.this,Cinemas.class);
                    startActivity(intent1);
                }

                if(pos.equals("Pizza Hut"))
                {
                    Intent intent=new Intent(Shoppingpage.this,Pizzahut.class);
                    startActivity(intent);
                }

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.optionlogin:
                Intent intent2 = new Intent(Shoppingpage.this, MainActivity.class);
                startActivity(intent2);
                return true;

            case R.id.optionsetting:
                Intent intent3 = new Intent(Shoppingpage.this, MainActivity.class);
                startActivity(intent3);
                return true;

            case R.id.optioncontact:
                Intent intent4 = new Intent(Shoppingpage.this, MainActivity.class);
                startActivity(intent4);

                return true;

            case R.id.optionhome:
                Intent intent5 = new Intent(Shoppingpage.this, MainActivity.class);
                startActivity(intent5);

                return true;

            default:
                return super.onOptionsItemSelected(item);


        }
    }


}

