package com.example.sagar.mantrimall;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Pizzahut extends AppCompatActivity {

    ImageButton pizza1,pizza2,pizza3,pizza4;
    Spinner spinner1,spinner2,spinner3,spinner4;
    int cost1,cost2,cost3,cost4,total1=0,total2=0,total3=0,total4=0;
    TextView totalpay;

    String[] spin1={"1","2","3","4","5","6","7","8","9","10"};
    String[] spin2={"1","2","3","4","5","6","7","8","9","10"};
    String[] spin3={"1","2","3","4","5","6","7","8","9","10"};
    String[] spin4={"1","2","3","4","5","6","7","8","9","10"};




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizzahut);

        totalpay=(TextView)findViewById(R.id.totalpay);
        pizza1=(ImageButton)findViewById(R.id.pizza1);
        pizza2=(ImageButton)findViewById(R.id.pizza2);
        pizza3=(ImageButton)findViewById(R.id.pizza3);
        pizza4=(ImageButton)findViewById(R.id.pizza4);

        spinner1 = (Spinner)findViewById(R.id.spinner1);
        spinner2 = (Spinner)findViewById(R.id.spinner2);
        spinner3 = (Spinner)findViewById(R.id.spinner3);
        spinner4 = (Spinner)findViewById(R.id.spinner4);


        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(Pizzahut.this,android.R.layout.simple_spinner_dropdown_item,spin1);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(Pizzahut.this,android.R.layout.simple_spinner_dropdown_item,spin2);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(Pizzahut.this,android.R.layout.simple_spinner_dropdown_item,spin3);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(Pizzahut.this,android.R.layout.simple_spinner_dropdown_item,spin4);



        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter3);
        spinner4.setAdapter(adapter4);

        pizza1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    pizza1.setBackgroundColor(Color.BLACK);

                    cost1=150;
                    spinner1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String pos=spinner1.getItemAtPosition(position).toString();
                            Toast.makeText(Pizzahut.this,spinner1.getItemAtPosition(position).toString(),Toast.LENGTH_SHORT).show();

                            int quantity=Integer.parseInt(pos);
                            int total1=quantity*cost1;
                        }
                    });


                }



                return false;
            }
        });

        pizza2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    pizza2.setBackgroundColor(Color.BLACK);

                    cost2=200;
                    spinner2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String pos=spinner2.getItemAtPosition(position).toString();
                            int quantity=Integer.parseInt(pos);
                            int total2=quantity*cost2;
                        }
                    });


                }



                return false;
            }
        });

        pizza3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    pizza3.setBackgroundColor(Color.BLACK);

                    cost3=200;
//                    spinner3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                        @Override
//                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                            String pos=spinner3.getItemAtPosition(position).toString();
//                            int quantity=Integer.parseInt(pos);
//                            int total3=quantity*cost3;
//                        }
//                    });


                }



                return false;
            }
        });

        pizza4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    pizza4.setBackgroundColor(Color.BLACK);

                    cost4=250;
                    spinner4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String pos=spinner4.getItemAtPosition(position).toString();
                            int quantity=Integer.parseInt(pos);
                            int total4=quantity*cost4;
                        }
                    });


                }



                return false;
            }
        });

        int total=total1+total2+total3+total4;

        String pay=String.valueOf(total);

        totalpay.setText(pay);


    }
}
