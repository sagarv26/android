package com.example.sagar.mantrimall;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button login;
    EditText main_username,main_password;
    CheckBox signin;
    String name,pwd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login=(Button)findViewById(R.id.login);
        signin=(CheckBox)findViewById(R.id.main_signin);
        main_username=(EditText)findViewById(R.id.main_username);
        main_password=(EditText)findViewById(R.id.main_password);


        Bundle b = getIntent().getExtras();
        if (b!= null) {
            name = b.getString("name");
            pwd = b.getString("password");

            main_username.setText(name);
            main_password.setText(pwd);
        }

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1=new Intent(MainActivity.this,Signin.class);
                startActivity(intent1);
            }
        });



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                else{
//                    Toast.makeText(MainActivity.this,"Please sign in", Toast.LENGTH_SHORT).show();
//
//                Intent intent1=new Intent(MainActivity.this,Shoppingpage.class);
//                Bundle data1=getIntent().getExtras();
//                String username= data1.getString("name");
//                Bundle data2=getIntent().getExtras();
//                String pwd= data1.getString("pwd");
//                startActivity(intent1);
//                }

                String un=main_username.getText().toString();
                String pw=main_password.getText().toString();


                SharedPreferences sharedPreferences  =  getSharedPreferences("signindetails", Context.MODE_PRIVATE);
                String username =   sharedPreferences.getString("username","");
                String pswd =  sharedPreferences.getString("pswd","");

                if(un.equals("sagar") && pw.equals("sagar")|| un.equals(username) && pw.equals(pswd))
                {
                    Intent intent=new Intent(MainActivity.this,Mantri_menu.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"InValid Username or Password",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
