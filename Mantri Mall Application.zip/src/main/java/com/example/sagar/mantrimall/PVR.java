package com.example.sagar.mantrimall;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class PVR extends AppCompatActivity {

    ImageButton aseat1,aseat2,aseat3,aseat4,aseat5,aseat6,bseat1,bseat2,bseat3,bseat4,bseat5,bseat6,cseat1,cseat2,cseat3,cseat4,cseat5,cseat6,dseat1,dseat2,dseat3,dseat4,dseat5,dseat6,eseat1,eseat2,eseat3,eseat4,eseat5;
    TextView display;
    int count=0,total_Selected=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pvr);

        display=(TextView)findViewById(R.id.display);
        aseat1=(ImageButton)findViewById(R.id.aseat1);
        aseat2=(ImageButton)findViewById(R.id.aseat3);
        aseat3=(ImageButton)findViewById(R.id.aseat2);
        aseat4=(ImageButton)findViewById(R.id.aseat4);
        aseat5=(ImageButton)findViewById(R.id.aseat5);
        aseat6=(ImageButton)findViewById(R.id.aseat6);

        bseat1=(ImageButton)findViewById(R.id.bseat1);
        bseat2=(ImageButton)findViewById(R.id.bseat2);
        bseat3=(ImageButton)findViewById(R.id.bseat3);
        bseat4=(ImageButton)findViewById(R.id.bseat4);
        bseat5=(ImageButton)findViewById(R.id.bseat4);
        bseat6=(ImageButton)findViewById(R.id.bseat6);

        cseat1=(ImageButton)findViewById(R.id.cseat2);
        cseat2=(ImageButton)findViewById(R.id.cseat2);
        cseat3=(ImageButton)findViewById(R.id.cseat5);
        cseat4=(ImageButton)findViewById(R.id.cseat4);
        cseat5=(ImageButton)findViewById(R.id.cseat3);
        cseat6=(ImageButton)findViewById(R.id.cseat6);

        dseat1=(ImageButton)findViewById(R.id.dseat1);
        dseat2=(ImageButton)findViewById(R.id.dseat2);
        dseat3=(ImageButton)findViewById(R.id.dseat3);
        dseat4=(ImageButton)findViewById(R.id.dseat4);
        dseat5=(ImageButton)findViewById(R.id.dseat5);
        dseat6=(ImageButton)findViewById(R.id.dseat6);

        eseat1=(ImageButton)findViewById(R.id.eseat1);
        eseat2=(ImageButton)findViewById(R.id.eseat2);
        eseat3=(ImageButton)findViewById(R.id.eseat3);
        eseat4=(ImageButton)findViewById(R.id.eseat4);
        eseat5=(ImageButton)findViewById(R.id.eseat5);

        aseat1.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat1.setBackgroundColor(Color.GREEN);
                    display.setText("1");
                    count=1;
                    total_Selected++;

                    aseat1.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat1.setBackgroundColor(Color.GREEN);
                                aseat1.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat1.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat2.setBackgroundColor(Color.GREEN);
                    display.setText("2");
                    count=1;
                    total_Selected++;

                    bseat2.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat2.setBackgroundColor(Color.GREEN);
                                bseat2.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat2.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        aseat3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat3.setBackgroundColor(Color.GREEN);
                    display.setText("3");
                    count=1;
                    total_Selected++;

                    aseat3.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat3.setBackgroundColor(Color.GREEN);
                                aseat3.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat3.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });


        aseat4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat4.setBackgroundColor(Color.GREEN);
                    display.setText("4");
                    count=1;
                    total_Selected++;

                    aseat4.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat4.setBackgroundColor(Color.GREEN);
                                aseat4.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat4.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        aseat5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat5.setBackgroundColor(Color.GREEN);
                    display.setText("5");
                    count=1;
                    total_Selected++;

                    aseat5.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat5.setBackgroundColor(Color.GREEN);
                                aseat5.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat5.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        aseat6.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    aseat6.setBackgroundColor(Color.GREEN);
                    display.setText("6");
                    count=1;
                    total_Selected++;

                    aseat6.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                aseat6.setBackgroundColor(Color.GREEN);
                                aseat6.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            aseat6.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat1.setBackgroundColor(Color.GREEN);
                    display.setText("1");
                    count=1;
                    total_Selected++;

                    bseat1.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat1.setBackgroundColor(Color.GREEN);
                                bseat1.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat1.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat2.setBackgroundColor(Color.GREEN);
                    display.setText("2");
                    count=1;
                    total_Selected++;

                    bseat2.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat2.setBackgroundColor(Color.GREEN);
                                bseat2.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat2.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat3.setBackgroundColor(Color.GREEN);
                    display.setText("3");
                    count=1;
                    total_Selected++;

                    bseat3.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat3.setBackgroundColor(Color.GREEN);
                                bseat3.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat3.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });


        bseat4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat4.setBackgroundColor(Color.GREEN);
                    display.setText("4");
                    count=1;
                    total_Selected++;

                    bseat4.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat4.setBackgroundColor(Color.GREEN);
                                bseat4.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat4.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat5.setBackgroundColor(Color.GREEN);
                    display.setText("5");
                    count=1;
                    total_Selected++;

                    bseat5.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat5.setBackgroundColor(Color.GREEN);
                                bseat5.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat5.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });

        bseat6.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    bseat6.setBackgroundColor(Color.GREEN);
                    display.setText("6");
                    count=1;
                    total_Selected++;

                    bseat6.setOnTouchListener(new View.OnTouchListener() {
                        @Override

                        public boolean onTouch(View v, MotionEvent event) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                count=2;
                                bseat6.setBackgroundColor(Color.GREEN);
                                bseat6.setOnClickListener(new View.OnClickListener() {
                                    @Override

                                    public void onClick(View v) {
                                        count=2;
                                        if(count==2) {
                                            bseat6.setBackgroundColor(Color.RED);

                                            LayoutInflater layoutInflater = getLayoutInflater();

                                            View booked1 = layoutInflater.inflate(R.layout.booked1, (ViewGroup) findViewById(R.id.booked1));

                                            Toast toast = new Toast(getApplicationContext());
                                            toast.setDuration(Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.setView(booked1);
                                            toast.show();
                                        }
                                    }

                                });

                            }
                            return false;
                        }

                    });

                }
                return false;
            }
        });





    }
}
