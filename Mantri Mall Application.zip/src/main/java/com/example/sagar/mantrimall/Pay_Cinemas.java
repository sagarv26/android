package com.example.sagar.mantrimall;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class Pay_Cinemas extends AppCompatActivity {

    String total;
    TextView disp,totalcost;
    int seats,cost=150,total_cost;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay__cinemas);

        disp=(TextView)findViewById(R.id.disp);
        totalcost=(TextView)findViewById(R.id.totalcost);

//       total= getIntent().getExtras().getString("total");
//       disp.setText(String.valueOf(total));
//       disp.setText(total);
//       Bundle b = getIntent().getExtras();
//       seats= b.getInt("total");

//        disp.setText(Integer.toString(getIntent().getExtras().getInt("total")));


        Bundle b=getIntent().getExtras();
        String number=b.getString("total");
        disp.setText(number);

        seats=Integer.parseInt(number);
        total_cost=cost*seats;

        total=String.valueOf(total_cost);

        totalcost.setText(total+" /-");











    }
}
