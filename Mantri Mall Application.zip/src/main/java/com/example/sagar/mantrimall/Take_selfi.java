package com.example.sagar.mantrimall;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class Take_selfi extends AppCompatActivity {

    ImageView selfi;
    Button takeselfi;
    String[] STORAGE_PERMISSION = {

            Manifest.permission.CAMERA
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_selfi);

        takeselfi=(Button)findViewById(R.id.takeselfi);
        selfi=(ImageView)findViewById(R.id.selfi);
        int pic_permission =  ContextCompat.checkSelfPermission(Take_selfi.this,Manifest.permission.CAMERA);

        if(pic_permission != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(Take_selfi.this,STORAGE_PERMISSION,1);
        }



        takeselfi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,111);

            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 111) {
            Bitmap photo=(Bitmap)data.getExtras().get("data");
            selfi.setImageBitmap(photo);
            Toast.makeText(Take_selfi.this, "Captured", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Take_selfi.this, "Not oki", Toast.LENGTH_SHORT).show();
        }


    }



}
