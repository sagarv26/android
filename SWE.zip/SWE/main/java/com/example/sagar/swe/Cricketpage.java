package com.example.sagar.swe;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class Cricketpage extends AppCompatActivity {

    Button cricbuzz_button,espn_button,ndtv_button;

    String[] STORAGE_PERMISSION = {

            Manifest.permission.INTERNET
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sports_cricket);

        ndtv_button=(Button)findViewById(R.id.ndtv_button);
        cricbuzz_button=(Button)findViewById(R.id.cricbuz_button);
        espn_button=(Button)findViewById(R.id.espn_button);
        final WebView webView = (WebView)findViewById(R.id.cricbuzweb);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        int value = ContextCompat.checkSelfPermission(Cricketpage.this, Manifest.permission.INTERNET);

        if(value != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(Cricketpage.this,STORAGE_PERMISSION,1);
        }

        cricbuzz_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(Intent.ACTION_VIEW);
//                i.setData(Uri.parse("http://www.cricbuzz.com"));
//                startActivity(i);

                webView.getSettings().setJavaScriptEnabled(true);
                webView.setWebViewClient(new WebViewClient());
                webView.loadUrl("http://www.cricbuzz.com");
                
            }
        });

        espn_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(Intent.ACTION_VIEW);
                i1.setData(Uri.parse("http://www.espncricinfo.com"));
                startActivity(i1);
            }
        });

        ndtv_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse("http://www.sports.ndtv.com"));
                startActivity(i2);
            }
        });

    }
}
