package com.example.sagar.swe;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.sagar.swe.Contactfetching.Contactfetching;

public class Call_friends extends AppCompatActivity {

    Button one,two,three,four,five,six,seven,eight,nine,zero,hash,astrix,friendcontact;
    EditText callnumber;
    String callno;
    FloatingActionButton mPhoneCallListener;
    ActionBar actionBar;
    String[] Storage_Permission={

            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_friends);
        setTitle("Call Your Friend");

//        one=(Button)findViewById(R.id.one);
//        two=(Button)findViewById(R.id.two);
//        three=(Button)findViewById(R.id.three);
//        four=(Button)findViewById(R.id.four);
//        five=(Button)findViewById(R.id.five);
//        six=(Button)findViewById(R.id.six);
//        seven=(Button)findViewById(R.id.seven);
//        eight=(Button)findViewById(R.id.eight);
//        nine=(Button)findViewById(R.id.nine);
//        zero=(Button)findViewById(R.id.zero);
//        astrix=(Button)findViewById(R.id.astrix);
//        hash=(Button)findViewById(R.id.hash);


        friendcontact=(Button)findViewById(R.id.friendcontact);
        callnumber=(EditText)findViewById(R.id.callnumber);
        mPhoneCallListener=(FloatingActionButton)findViewById(R.id.dialbutton);

 /**
 * A call-back for when the user presses the number buttons.
 * */

        View.OnClickListener mDialPadListener=new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer previousNumber = new StringBuffer(callnumber.getText().toString());
                CharSequence phoneDigit = ((Button)v).getText();
                callnumber.setText(previousNumber.append(phoneDigit));
            }
        };

        friendcontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent contactintent=new Intent(Call_friends.this, Contactfetching.class);
                startActivity(contactintent);
            }
        });


 /**
 * A call-back for when the user presses the call button.
 * */

        mPhoneCallListener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                call(callnumber.getText().toString());
            }
        });




// Hook up button presses to the appropriate event handler.

        ((Button) findViewById(R.id.one)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.two)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.three)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.four)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.five)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.six)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.seven)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.eight)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.nine)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.zero)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.astrix)).setOnClickListener(mDialPadListener);
        ((Button) findViewById(R.id.hash)).setOnClickListener(mDialPadListener);


    }



    private void call(String phoneNumber) {

        try {
            int call_permission= ContextCompat.checkSelfPermission(Call_friends.this,Manifest.permission.CALL_PHONE);
            if(call_permission!=PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(Call_friends.this,Storage_Permission,1);
            }

            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:"+ phoneNumber));
            startActivity(callIntent);
        } catch (ActivityNotFoundException activityException) {
            Log.e("dialing-example", "Call failed", activityException);
        }
    }


}



