package com.example.sagar.swe;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Sagar on 4/1/2017.
 */

public class Customlist extends BaseAdapter {
    String[] listname;
    int[] listimage;
    LayoutInflater li=null;
    Context context;


    public Customlist(Page1 context,String[] listname,int[] listimage)
    {
        this.listname=listname;
        this.listimage=listimage;
        this.context=context;
        li=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    class viewholder
    {
        ImageView itemimage;
        TextView itemname;
    }

    @Override
    public int getCount() {
        return listname.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Inflating the layout
        viewholder vh=new viewholder();
        convertView=li.inflate(R.layout.customlist,null);

        //Get the reference to View Object
        vh.itemname=(TextView)convertView.findViewById(R.id.item_name);
        vh.itemimage=(ImageView)convertView.findViewById(R.id.item_image);

        //Specifying the Position
        vh.itemimage.setImageResource(listimage[position]);
        vh.itemname.setText(listname[position]);

        return convertView;
    }
}
