package com.example.sagar.swe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signin extends AppCompatActivity {

    EditText signin_username, signin_password, mobile, city;
    Button signin_button;
    String un, pw;
    int count = 0;
    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        signin_username = (EditText) findViewById(R.id.signin_username);
        signin_password = (EditText) findViewById(R.id.signin_password);
        mobile = (EditText) findViewById(R.id.mobile);
        city = (EditText) findViewById(R.id.city);
        signin_button = (Button) findViewById(R.id.signin_button);

        sharedpreferences = getSharedPreferences("signindetails", Context.MODE_PRIVATE);
    }

    public void click(View v) {

        un = signin_username.getText().toString();
        pw = signin_password.getText().toString();
        String number = mobile.getText().toString();
        if (un.equals("sagar") || number.equals("8722548007")) {
            Toast.makeText(Signin.this, "Please Provide another name or Number", Toast.LENGTH_LONG).show();
        } else {

            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putString("username", un);
            editor.putString("pswd", pw);
            editor.putString("mobno", number);
            editor.commit();
            Toast.makeText(Signin.this, "Thanks", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("name", un);
//            Log.e("Name:", un);
            intent.putExtra("password", pw);
//            Log.e("Password:", pw);
            //start the DisplayActivity
            startActivity(intent);
        }


    }
}
