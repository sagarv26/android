package com.example.sagar.swe;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Sports extends AppCompatActivity {
    String[] sports_name={"Cricket","Football","Tennis","Kabbadi","Hockey","Golf"};
    int[] sports_image={R.drawable.cricketimage,R.drawable.footballimage,R.drawable.tennisimage,R.drawable.kabbaddiimage,R.drawable.hockeyimage,R.drawable.golfimage};
    GridView sports_gridview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports);
        sports_gridview=(GridView)findViewById(R.id.sports_gridview);

        sports_gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pos = parent.getItemAtPosition(position).toString();
                Toast.makeText(Sports.this, "Selected Application is : " + pos, Toast.LENGTH_SHORT).show();


                if (pos.equals("Cricket")) {
                    Intent i = new Intent(Sports.this, Cricketpage.class);
                    startActivity(i);
                }

                if (pos.equals("1")) {
                    Intent intent = new Intent(Sports.this, Callfriends.class);
                    startActivity(intent);
                }

                if (pos.equals("3")) {
                    Intent intent = new Intent(Sports.this, Sports.class);
                    startActivity(intent);
                }
            }
        }) ;

        MyAdapter adapter=new MyAdapter(Sports.this,sports_name,sports_image);
        sports_gridview.setAdapter(adapter);
    }


}

    class MyAdapter extends ArrayAdapter{
    int[] sportspic;
    String[] sportstitle;

    public MyAdapter(@NonNull Context context, @LayoutRes int resource) {
        super(context, resource);
    }


    public MyAdapter(Context context,String[] sportstitle,int[] sportspic)
    {
        super(context, R.layout.sports_customlist,R.id.sports_name,sportstitle);
        this.sportstitle=sportstitle;
        this.sportspic=sportspic;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inf=(LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inf.inflate(R.layout.sports_customlist,parent,false);

        ImageView sports_imageview=(ImageView)row.findViewById(R.id.sports_imageview);
        TextView sports_name=(TextView)row.findViewById(R.id.sports_name);

        sports_imageview.setImageResource(sportspic[position]);
        sports_name.setText(sportstitle[position]);
        return row;
    }


}
